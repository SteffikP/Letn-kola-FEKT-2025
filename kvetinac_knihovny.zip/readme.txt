Pro informace jak instalovat knihovny se podívej na: http://www.arduino.cc/en/Guide/Libraries
